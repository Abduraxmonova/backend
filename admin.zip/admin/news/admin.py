from django.contrib import admin
from .models import Employee,Company,Profile,Blog
# Register your models here.
admin.site.register(Employee)
admin.site.register(Company)
admin.site.register(Profile)
admin.site.register(Blog)
