from django.db import models

# Create your models here.
class Employee(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    salary = models.DecimalField(max_digits=5,decimal_places=3)
    
    def __str__(self) -> str:
        return self.name
    
class Company(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    category = models.CharField(max_length=40)
    founded = models.IntegerField()
    ceo = models.CharField(max_length=40)
    info = models.TextField()
    create_at = models.DateTimeField(auto_now=True)
    update_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self) -> str:
        return self.name

class Profile(models.Model):
    name = models.CharField(max_length=100)
    familya = models.CharField(max_length=100)
    image = models.ImageField(upload_to="images")

    def __str__(self):
        return self.name
    
class Blog(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='image')
    discription = models.TextField()
    date = models.DateField()
    created_at = models.DateTimeField(auto_now=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
    
    