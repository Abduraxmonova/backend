from django.shortcuts import render
from .models import Blog
# Create your views here.
def index(req):
    data = Blog.objects.all()
    # context = {
    #     'data':data
    # }
    return render(req,'index.html',{'data':data})


def single(req, id):
    data=Blog.objects.get(id=id)
    return render (req,'single.html',{'data':data})
