from django.urls import path 
from .views import index, about, contact, project, service, test
urlpatterns = [
    path('',index, name='i'),
    path('about',about, name='about'),
    path('p',project, name='p'),
    path('c',contact,name='c'),
    path('service',service,name='service'),
    path('t',test,name='t'),
    ]
