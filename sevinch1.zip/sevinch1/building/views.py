from django.shortcuts import render

# Create your views here.
def index(request):
    return render (request, 'index.html')
 
def about(request):
    return render (request, 'about.html')
def contact(request):
    return render (request,'contact.html')

def project(request):
    return render(request,'project.html')

def service(request):
    return render (request,'service.html')

def test(request):
    return render (request,'testimonial.html')